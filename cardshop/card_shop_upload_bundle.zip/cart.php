<?php
session_start(); include 'check_remember.php'; include 'db_config.php';
if (!isset($_SESSION['user_id'])) { header("Location: signin.php"); exit(); }

$cart  = $_SESSION['cart'] ?? [];
$total = 0;
$cart_products = [];

foreach ($cart as $pid => $item) {
    $stmt = $conn->prepare("SELECT * FROM products WHERE id=? AND is_active=1");
    $stmt->bind_param("i", $pid);
    $stmt->execute();
    $p = $stmt->get_result()->fetch_assoc();
    if ($p) { $cart_products[$pid] = array_merge($item, $p); $total += $item['price'] * $item['quantity']; }
}
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8"><title>購物車 | Card Shop</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body { display:block; }
        .cart-box { max-width:700px; margin:50px auto; padding:0 20px; }
        h2 { color:var(--primary-color); text-align:center; margin-bottom:25px; }
        table { width:100%; border-collapse:collapse; background:#fff; border-radius:12px; overflow:hidden; box-shadow:0 4px 15px rgba(194,163,142,.15); }
        th { background:var(--secondary-color); color:var(--text-color); padding:12px 15px; text-align:left; font-size:.9rem; }
        td { padding:12px 15px; border-bottom:1px solid var(--bg-color); vertical-align:middle; font-size:.9rem; }
        tr:last-child td { border-bottom:none; }
        .thumb { width:45px; height:60px; object-fit:cover; border-radius:6px; }
        .del-link { color:#e74c3c; text-decoration:none; font-weight:bold; }
        .total-bar { text-align:right; margin-top:20px; font-size:1.1rem; font-weight:bold; color:var(--text-color); }
        .total-bar span { color:var(--primary-color); font-size:1.3rem; }
        .btn-row { display:flex; justify-content:center; gap:15px; margin-top:20px; }
        .btn-row button { width:180px; }
        .btn-secondary { background:var(--secondary-color)!important; color:var(--text-color)!important; }
    </style>
</head>
<body>
<div class="cart-box">
    <h2>🛒 我的購物車</h2>
    <?php if (empty($cart_products)): ?>
        <p style="text-align:center; color:#aaa; padding:40px;">購物車是空的</p>
        <div style="text-align:center;"><a href="index.php">← 去逛逛</a></div>
    <?php else: ?>
    <table>
        <tr><th>圖片</th><th>商品</th><th>單價</th><th>數量</th><th>小計</th><th>操作</th></tr>
        <?php foreach ($cart_products as $pid => $item): ?>
        <tr>
            <td><img src="<?php echo htmlspecialchars($item['image_path']); ?>" class="thumb" onerror="this.style.display='none'"></td>
            <td><?php echo htmlspecialchars($item['name']); ?></td>
            <td>$ <?php echo number_format($item['price']); ?></td>
            <td><?php echo $item['quantity']; ?></td>
            <td>$ <?php echo number_format($item['price'] * $item['quantity']); ?></td>
            <td><a href="remove_from_cart.php?id=<?php echo $pid; ?>" class="del-link">刪除</a></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <div class="total-bar">總計金額：<span>$ <?php echo number_format($total); ?></span></div>
    <div class="btn-row">
        <button class="btn-secondary" onclick="location.href='index.php'">繼續逛逛</button>
        <button onclick="location.href='checkout.php'">前往結帳</button>
    </div>
    <?php endif; ?>
</div>
</body>
</html>
