<?php
session_start(); include 'db_config.php';
if (!isset($_SESSION['user_id'])) { header("Location: signin.php"); exit(); }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header("Location: index.php"); exit(); }

$pid = intval($_POST['product_id'] ?? 0);
if ($pid <= 0) { header("Location: index.php"); exit(); }

$stmt = $conn->prepare("SELECT * FROM products WHERE id=? AND is_active=1 AND status='available'");
$stmt->bind_param("i", $pid);
$stmt->execute();
$p = $stmt->get_result()->fetch_assoc();

if (!$p) {
    echo "<script>alert('此商品已售出或不存在'); window.location.href='index.php';</script>"; exit();
}

if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
$key = (string)$pid;
if (isset($_SESSION['cart'][$key])) {
    $_SESSION['cart'][$key]['quantity']++;
} else {
    $_SESSION['cart'][$key] = ['name'=>$p['name'], 'price'=>$p['price'], 'image_path'=>$p['image_path'], 'quantity'=>1];
}
header("Location: index.php"); exit();
?>
