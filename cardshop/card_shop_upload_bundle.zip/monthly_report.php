<?php
declare(strict_types=1);

require_once __DIR__ . '/check_remember.php';
require_login(['seller', 'admin']);

$month = preg_match('/^\d{4}-\d{2}$/', (string) ($_GET['month'] ?? '')) ? (string) $_GET['month'] : date('Y-m');
$summary = monthly_sales_summary((int) current_user()['id'], $month);
$orders = seller_monthly_orders((int) current_user()['id'], $month);

$pageTitle = '月報 | ' . APP_NAME;
require_once __DIR__ . '/partials/header.php';
?>
<section class="app-section">
    <div class="section-head">
        <div>
            <h2>月報</h2>
            <p class="muted"><?= h($month) ?> ・ <?= (int) $summary['total_orders'] ?> 筆 ・ <?= (int) $summary['total_cards'] ?> 張 ・ <?= h(format_currency((float) $summary['total_revenue'])) ?></p>
        </div>
        <a class="button secondary" href="monthly_report_pdf.php?month=<?= h($month) ?>">PDF</a>
    </div>

    <form method="get" class="filter-inline">
        <div class="field" style="margin-bottom: 0;">
            <label for="month">月份</label>
            <select id="month" name="month">
                <?php foreach (month_options(12) as $value => $label): ?>
                    <option value="<?= h($value) ?>" <?= $month === $value ? 'selected' : '' ?>><?= h($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit">套用</button>
    </form>
</section>

<section class="app-section">
    <h3 class="section-title">訂單</h3>
    <?php if ($orders === []): ?>
        <p class="muted">這個月份還沒有成交。</p>
    <?php else: ?>
        <div class="simple-list">
            <?php foreach ($orders as $order): ?>
                <article class="list-row">
                    <div>
                        <strong><?= h($order['product_name']) ?></strong>
                        <p class="muted-small"><?= h($order['buyer_name']) ?> ・ <?= (int) $order['quantity'] ?> 張</p>
                    </div>
                    <div class="list-row-meta">
                        <span><?= h(format_currency((float) $order['total_amount'])) ?></span>
                        <span class="muted-small"><?= h($order['created_at']) ?></span>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>
<?php require_once __DIR__ . '/partials/footer.php'; ?>
