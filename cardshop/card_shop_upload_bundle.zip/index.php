<?php
declare(strict_types=1);

require_once __DIR__ . '/check_remember.php';

$stmt = db()->query(
    'SELECT
        p.*,
        u.display_name,
        u.id AS seller_user_id,
        (SELECT pi.image_path FROM product_images pi WHERE pi.product_id = p.id ORDER BY pi.is_primary DESC, pi.id ASC LIMIT 1) AS primary_image
     FROM products p
     INNER JOIN users u ON u.id = p.seller_id
     ORDER BY p.created_at DESC
     LIMIT 6'
);
$products = $stmt->fetchAll();

$pageTitle = APP_NAME;
require_once __DIR__ . '/partials/header.php';
?>
<section>
    <h2>T's cashop</h2>
    <p class="muted-small">最新上架</p>
</section>

<section class="products-grid">
    <?php foreach ($products as $product): ?>
        <article class="product-card">
            <div class="product-cover">
                <img src="<?= h(product_primary_image($product['primary_image'])) ?>" alt="<?= h($product['name']) ?>">
            </div>
            <div class="badge-row">
                <span class="badge"><?= h($product['group_name']) ?></span>
                <span class="badge"><?= h(product_status_label((string) $product['status'], (int) $product['stock'])) ?></span>
            </div>
            <h3><?= h($product['name']) ?></h3>
            <p class="muted-small"><?= h($product['member_name']) ?> ・ <?= h($product['card_version']) ?></p>
            <div class="price"><?= h(format_currency((float) $product['price'])) ?></div>
        </article>
    <?php endforeach; ?>
</section>
<?php require_once __DIR__ . '/partials/footer.php'; ?>
