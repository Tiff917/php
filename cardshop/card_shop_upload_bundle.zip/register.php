<?php
declare(strict_types=1);

require_once __DIR__ . '/check_remember.php';

if (is_logged_in()) {
    redirect('member_center.php');
}

$pageTitle = '註冊 | ' . APP_NAME;
require_once __DIR__ . '/partials/header.php';
?>
<section class="auth-block">
    <a class="back-link" href="signin.php">← 返回登入</a>
    <h2>註冊</h2>
    <p class="muted auth-copy">建立帳號後就可以開始收藏與交易小卡。</p>
    <form method="post" action="register_process.php" class="auth-form">
        <div class="field">
            <div class="field-head">
                <label for="display_name">名稱</label>
                <span class="field-hint">目前輸入這一欄</span>
            </div>
            <input id="display_name" name="display_name" required>
        </div>
        <div class="field">
            <div class="field-head">
                <label for="username">帳號</label>
                <span class="field-hint">目前輸入這一欄</span>
            </div>
            <input id="username" name="username" required>
        </div>
        <div class="field">
            <div class="field-head">
                <label for="email">Email</label>
                <span class="field-hint">目前輸入這一欄</span>
            </div>
            <input id="email" name="email" type="email" required>
        </div>
        <div class="field">
            <div class="field-head">
                <label for="role">身份</label>
                <span class="field-hint">目前輸入這一欄</span>
            </div>
            <select id="role" name="role" required>
                <option value="buyer">買家</option>
                <option value="seller">賣家</option>
            </select>
        </div>
        <div class="field">
            <div class="field-head">
                <label for="password">密碼</label>
                <span class="field-hint">目前輸入這一欄</span>
            </div>
            <input id="password" name="password" type="password" minlength="6" required>
        </div>
        <div class="field">
            <div class="field-head">
                <label for="password_confirm">確認密碼</label>
                <span class="field-hint">目前輸入這一欄</span>
            </div>
            <input id="password_confirm" name="password_confirm" type="password" minlength="6" required>
        </div>
        <button type="submit">建立帳號</button>
    </form>
    <div class="auth-switch">
        <span>已有帳號？</span>
        <a href="signin.php">立即登入</a>
    </div>
</section>
<?php require_once __DIR__ . '/partials/footer.php'; ?>
