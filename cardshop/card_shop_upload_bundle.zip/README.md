# T's cashop

韓系小卡交易平台，使用 PHP + MySQL 建立，並整合 PWA、交易流程、郵件通知、評價系統、GD 浮水印與每月 PDF 報表。

## 主要功能

- Cookie Remember Me 自動登入
- 多圖上傳與主圖預覽
- 團體名稱與卡況標籤篩選
- 賣家評價系統
- GD 圖片浮水印與星等圖表
- PHPMailer 寄信通知
- 每月銷售 PDF 匯出

## 本機使用

1. 把整個 `card_shop` 資料夾放到 XAMPP 的 `htdocs`
2. 啟動 Apache 與 MySQL
3. 匯入根目錄的 `card_shop.sql`，或開啟 `http://localhost/card_shop/migrate_v2.php`
4. 開啟 `http://localhost/card_shop/signin.php`

## 測試帳號

- admin / admin123
- seller01 / seller123
- buyer01 / buyer123

## 重要提醒

- `config.php` 內的 SMTP 目前是範例值，請改成自己的寄信帳號
- `pdo_mysql` 與 `gd` 必須啟用
- 可用 `health_check.php` 快速確認本機環境
