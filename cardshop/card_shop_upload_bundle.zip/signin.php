<?php
declare(strict_types=1);

require_once __DIR__ . '/check_remember.php';

if (is_logged_in()) {
    redirect('index.php');
}

$pageTitle = '登入 | ' . APP_NAME;
require_once __DIR__ . '/partials/header.php';
?>
<section class="auth-block">
    <h2>登入</h2>
    <p class="muted auth-copy">新用戶也可以直接註冊開始使用。</p>
    <form method="post" action="signin_process.php" class="auth-form">
        <div class="field">
            <div class="field-head">
                <label for="username">帳號</label>
                
            </div>
            <input id="username" name="username" autocomplete="username" required>
        </div>
        <div class="field">
            <div class="field-head">
                <label for="password">密碼</label>
            </div>
            <input id="password" name="password" type="password" autocomplete="current-password" required>
        </div>
        <label class="inline-check">
            <input type="checkbox" name="remember_me" value="1">
            <span>7 天免登入</span>
        </label>
        <button type="submit">登入</button>
    </form>
    <div class="auth-switch">
        <span>還沒有帳號？</span>
        <a href="register.php">立即註冊</a>
    </div>
</section>
<?php require_once __DIR__ . '/partials/footer.php'; ?>
