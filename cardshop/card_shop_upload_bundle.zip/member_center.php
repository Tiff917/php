<?php
declare(strict_types=1);

require_once __DIR__ . '/check_remember.php';
require_login();

$user = fetch_user_by_id(current_user()['id']);

$ordersStmt = db()->prepare(
    'SELECT o.*, p.name AS product_name
     FROM orders o
     INNER JOIN products p ON p.id = o.product_id
     WHERE o.buyer_id = :buyer_id
     ORDER BY o.created_at DESC'
);
$ordersStmt->execute(['buyer_id' => current_user()['id']]);
$orders = $ordersStmt->fetchAll();

$pageTitle = '會員 | ' . APP_NAME;
require_once __DIR__ . '/partials/header.php';
?>
<section>
    <h2><?= h($user['display_name']) ?></h2>
    <p class="muted-small">@<?= h($user['username']) ?></p>
</section>

<section class="panel">
    <form method="post" action="update_profile.php">
        <div class="field">
            <label for="display_name">名稱</label>
            <input id="display_name" name="display_name" value="<?= h($user['display_name']) ?>" required>
        </div>
        <div class="field">
            <label for="email">Email</label>
            <input id="email" name="email" type="email" value="<?= h($user['email']) ?>" required>
        </div>
        <div class="field">
            <label for="phone">手機</label>
            <input id="phone" name="phone" value="<?= h($user['phone'] ?? '') ?>">
        </div>
        <div class="field">
            <label for="address">地址</label>
            <input id="address" name="address" value="<?= h($user['address'] ?? '') ?>">
        </div>
        <div class="field">
            <label for="new_password">新密碼</label>
            <input id="new_password" name="new_password" type="password" minlength="6">
        </div>
        <button type="submit">儲存</button>
    </form>
</section>

<section class="panel">
    <h2>訂單</h2>
    <div class="review-list">
        <?php foreach ($orders as $order): ?>
            <article class="review-card">
                <p><strong><?= h($order['product_name']) ?></strong></p>
                <p class="muted-small"><?= h(format_currency((float) $order['total_amount'])) ?></p>
                <a class="button secondary" href="review.php?order_id=<?= (int) $order['id'] ?>">評價</a>
            </article>
        <?php endforeach; ?>
    </div>
</section>
<?php require_once __DIR__ . '/partials/footer.php'; ?>
