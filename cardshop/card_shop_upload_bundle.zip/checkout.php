<?php
declare(strict_types=1);

require_once __DIR__ . '/check_remember.php';
require_once __DIR__ . '/mail_helpers.php';
require_login(['buyer']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('index.php');
}

$productId = (int) ($_POST['product_id'] ?? 0);
$quantity = max(1, (int) ($_POST['quantity'] ?? 1));

$stmt = db()->prepare(
    'SELECT p.*, u.display_name AS seller_name, u.email AS seller_email, u.phone AS seller_phone
     FROM products p
     INNER JOIN users u ON u.id = p.seller_id
     WHERE p.id = :id
     LIMIT 1'
);
$stmt->execute(['id' => $productId]);
$product = $stmt->fetch();

if (!$product || $product['status'] === 'sold_out' || (int) $product['stock'] < $quantity) {
    set_flash('flash_error', '商品不可購買。');
    redirect('index.php');
}

$pdo = db();
$pdo->beginTransaction();

try {
    $newStock = (int) $product['stock'] - $quantity;
    $newStatus = $newStock <= 0 ? 'sold_out' : 'active';
    $paidAt = date('Y-m-d H:i:s');

    $orderStmt = $pdo->prepare(
        'INSERT INTO orders
            (product_id, buyer_id, seller_id, quantity, total_amount, status, created_at, paid_at)
         VALUES
            (:product_id, :buyer_id, :seller_id, :quantity, :total_amount, :status, NOW(), :paid_at)'
    );
    $orderStmt->execute([
        'product_id' => $productId,
        'buyer_id' => current_user()['id'],
        'seller_id' => $product['seller_id'],
        'quantity' => $quantity,
        'total_amount' => $quantity * (float) $product['price'],
        'status' => 'paid',
        'paid_at' => $paidAt,
    ]);

    $orderId = (int) $pdo->lastInsertId();

    $updateStmt = $pdo->prepare(
        'UPDATE products
         SET stock = :stock,
             status = :status,
             updated_at = NOW(),
             sold_at = :sold_at
         WHERE id = :id'
    );
    $updateStmt->execute([
        'stock' => $newStock,
        'status' => $newStatus,
        'sold_at' => $newStock <= 0 ? $paidAt : null,
        'id' => $productId,
    ]);

    $pdo->commit();

    $buyer = fetch_user_by_id(current_user()['id']);
    $seller = fetch_user_by_id((int) $product['seller_id']);
    $order = [
        'id' => $orderId,
        'quantity' => $quantity,
        'total_amount' => $quantity * (float) $product['price'],
        'paid_at' => $paidAt,
    ];
    $mailNotice = send_order_notifications($order, $buyer, $seller, $product);
} catch (Throwable $e) {
    $pdo->rollBack();
    set_flash('flash_error', '結帳失敗。');
    redirect('index.php');
}

$pageTitle = '完成 | ' . APP_NAME;
require_once __DIR__ . '/partials/header.php';
?>
<section class="app-section">
    <h2>完成</h2>
    <div class="simple-list">
        <div class="list-row">
            <span>商品</span>
            <strong><?= h($product['name']) ?></strong>
        </div>
        <div class="list-row">
            <span>卡片</span>
            <strong><?= h($product['group_name']) ?> ・ <?= h($product['member_name']) ?></strong>
        </div>
        <div class="list-row">
            <span>數量</span>
            <strong><?= (int) $quantity ?></strong>
        </div>
        <div class="list-row">
            <span>金額</span>
            <strong><?= h(format_currency($quantity * (float) $product['price'])) ?></strong>
        </div>
        <div class="list-row">
            <span>賣家</span>
            <strong><?= h($product['seller_name']) ?></strong>
        </div>
    </div>

    <?php if ($mailNotice): ?>
        <p class="muted" style="margin-top: 12px;"><?= h($mailNotice) ?></p>
    <?php endif; ?>

    <div class="stack-row" style="margin-top: 16px;">
        <a class="button" href="review.php?order_id=<?= $orderId ?>">評價</a>
        <a class="button secondary" href="index.php">首頁</a>
    </div>
</section>
<?php require_once __DIR__ . '/partials/footer.php'; ?>
