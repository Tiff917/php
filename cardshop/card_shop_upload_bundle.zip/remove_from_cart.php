<?php
session_start();
if (!isset($_SESSION['user_id'])) { header("Location: signin.php"); exit(); }
$id = (string)intval($_GET['id'] ?? 0);
if (isset($_SESSION['cart'][$id])) unset($_SESSION['cart'][$id]);
header("Location: cart.php"); exit();
?>
